package kr.ezen.jung.service;

public interface MailService {
	public String mailSend(String to);
}
