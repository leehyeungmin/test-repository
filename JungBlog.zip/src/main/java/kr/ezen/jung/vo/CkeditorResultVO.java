package kr.ezen.jung.vo;

import lombok.Data;

@Data
public class CkeditorResultVO {
	private int uploaded;
	private String fileName;
	private String url;
}
