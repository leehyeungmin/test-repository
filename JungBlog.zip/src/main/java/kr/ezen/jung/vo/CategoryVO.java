package kr.ezen.jung.vo;

import lombok.Data;

@Data
public class CategoryVO {
	private int idx;
	private String categoryName;
}
