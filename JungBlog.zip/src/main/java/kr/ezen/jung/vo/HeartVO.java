package kr.ezen.jung.vo;

import lombok.Data;

@Data
public class HeartVO {
	private int idx;
	private int userRef; //user idx
	private int boardRef; //board idx
	
}
